package remijan.m.class2.lecture;

import java.net.Inet4Address;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class Ex01_EchoServer {

    public static void main(String[] args) throws Exception {
        System.out.printf("SERVER: %s: EchoServer I've started%n", Thread.currentThread().getName());

        System.out.printf("SERVER: %s: Creating pool of threads%n", Thread.currentThread().getName());
        ExecutorService pool = Executors.newFixedThreadPool(5);

        String address = Inet4Address.getLocalHost().getHostAddress();
        int port = 12727;
        System.out.printf("SERVER: %s: creating ServerSocket for %s/%d%n",
             Thread.currentThread().getName(), address, port);
        ServerSocket server = new ServerSocket(port);

        while (true) {
            System.out.printf("SERVER: %s: waiting to accept client connection....%n", Thread.currentThread().getName());
            // Main thread will block until a client connects to the server    
            Socket socket = server.accept();

            // After the #accept() method call unblocks and a connection
            // between client and server is established, create a 
            // Runnable for that socket so that communication between
            // the client and server can be done in another thread
            Ex01_SocketRunnable runnable
                = new Ex01_SocketRunnable(socket);

            // Run the runnable in a thread pool to free up the Main
            // thread to accept other connections.
            pool.execute(runnable);
        }
    }
}
