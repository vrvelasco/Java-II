package remijan.m.class2.lecture;

import java.net.Socket;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Formatter;
import java.util.List;
import java.util.Scanner;

public class Ex01_EchoClient {

    public static void main(String[] args) throws Exception {
        System.out.printf("CLIENT: EchoClient started%n");

        List<String> words = new ArrayList<>(6);
        Collections.addAll(words,
            "Hello",
            "Doctor",
            "Name",
            "Continue",
            "Yesterday",
            "Tomorrow"
        );

        System.out.printf("CLIENT: Creating socket%n");
        Socket socket
            = new Socket("localhost", 12727);

        Formatter toServer
            = new Formatter(socket.getOutputStream());

        Scanner fromServer
            = new Scanner(socket.getInputStream());

        for (;;) {
            words.forEach(w -> {
                try {
                    // write to server
                    toServer.format("%s%n", w);
                    toServer.flush();

                    // read from sever
                    String echoed = fromServer.nextLine();
                    System.out.printf("CLIENT: From server: \"%s\"%n", echoed);

                    // sleep a few seconds
                    Thread.sleep(1000 * 5);
                } catch (InterruptedException e) {
                    throw new RuntimeException(e);
                }
            });
        }
    }
}
