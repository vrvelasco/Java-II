package remijan.m.class2.lecture.ex02;

/**
 *
 * @author Michael Remijan mjremijan@yahoo.com @mjremijan
 */
public interface Command {
    void handle();
}
