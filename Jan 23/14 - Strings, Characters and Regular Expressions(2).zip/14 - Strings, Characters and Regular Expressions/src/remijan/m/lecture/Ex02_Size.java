package remijan.m.lecture;

public class Ex02_Size {
  public static void main(String[] args) {
    String name = "Michael";
    System.out.printf("length = %d%n", name.length());
   
    String emptyString = "";
    System.out.printf("emptyString is empty = %b%n", emptyString.isEmpty());
    
    String space = " ";
    System.out.printf("space is empty = %b%n", space.isEmpty());
  }
}
